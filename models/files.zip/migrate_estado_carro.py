"""
migrate_estado_carro.py
Agrega los campos estado, motivo_servicio y fecha_servicio a la tabla carros.

Ejecutar UNA SOLA VEZ:
    python migrate_estado_carro.py

En Render: Shell → python migrate_estado_carro.py

También agregar estos campos al modelo Carro en models/__init__.py:
    estado          = db.Column(db.String(20), nullable=False, default='operativo')
    motivo_servicio = db.Column(db.String(200), nullable=True)
    fecha_servicio  = db.Column(db.DateTime, nullable=True)
"""

from app import create_app
from models import db

app = create_app()

with app.app_context():
    with db.engine.connect() as con:

        # ── estado ──────────────────────────────────────────────
        res = con.execute(db.text(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_name='carros' AND column_name='estado'"
        ))
        if not res.fetchone():
            con.execute(db.text(
                "ALTER TABLE carros "
                "ADD COLUMN estado VARCHAR(20) NOT NULL DEFAULT 'operativo'"
            ))
            print("✅ Columna 'estado' agregada")
        else:
            print("ℹ️  Columna 'estado' ya existe")

        # ── motivo_servicio ──────────────────────────────────────
        res = con.execute(db.text(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_name='carros' AND column_name='motivo_servicio'"
        ))
        if not res.fetchone():
            con.execute(db.text(
                "ALTER TABLE carros ADD COLUMN motivo_servicio VARCHAR(200)"
            ))
            print("✅ Columna 'motivo_servicio' agregada")
        else:
            print("ℹ️  Columna 'motivo_servicio' ya existe")

        # ── fecha_servicio ───────────────────────────────────────
        res = con.execute(db.text(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_name='carros' AND column_name='fecha_servicio'"
        ))
        if not res.fetchone():
            con.execute(db.text(
                "ALTER TABLE carros ADD COLUMN fecha_servicio TIMESTAMP"
            ))
            print("✅ Columna 'fecha_servicio' agregada")
        else:
            print("ℹ️  Columna 'fecha_servicio' ya existe")

        con.execute(db.text("COMMIT"))

    print("\n✅ Migración completada.")
    print("   Todos los carros existentes quedan con estado='operativo'.")
    print("\n⚠️  Recordá agregar los campos al modelo Carro en models/__init__.py:")
    print("   estado          = db.Column(db.String(20), nullable=False, default='operativo')")
    print("   motivo_servicio = db.Column(db.String(200), nullable=True)")
    print("   fecha_servicio  = db.Column(db.DateTime, nullable=True)")
